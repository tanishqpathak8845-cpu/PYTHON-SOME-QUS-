# repeat qus 2.5 but this time  represent the famous person name using a veriable called famous person.
famous_person = "Albart Einstein "
quote = "once said , A person who naver made a mistake naver tried anythink new"
print(f"{famous_person}", quote)