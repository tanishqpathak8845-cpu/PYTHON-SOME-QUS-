# use a verable to represent a person's name and inclulde some whitespace char.
name = 'tanishq' 
print("\ttanishq")
print("\ntanishq")
name.rstrip() 
name.lstrip()
name.strip()