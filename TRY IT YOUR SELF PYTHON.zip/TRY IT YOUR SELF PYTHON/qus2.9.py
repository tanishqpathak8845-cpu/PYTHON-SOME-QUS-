# write addition substractionn multiplication and division operation such that each result in the number 8.
print(5+3)
print(9-1)
print(4*2)
print(16/2)