# find a quote from a famous person you admire print the quote and the name of its aurthor .
quote = 'Albart Einstine once said',  "A person who naver made a mistake naver tried anythink new "
print(quote)