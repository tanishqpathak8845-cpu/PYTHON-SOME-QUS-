# adding commennt  
# coder
name = "tanishq" 
print(name)