# use  a veriable to represent your fav number
favorite_number = 15 , 20 , 45, 18, 13
message = (f"{favorite_number}, these are my fav number ")
print(message)