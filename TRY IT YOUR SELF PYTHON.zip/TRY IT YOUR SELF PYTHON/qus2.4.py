# use a veriable to represent a person's name to uppercase lowercase and title case .
name = "tAniShq"
print(name.upper())
print(name.lower())
print(name.title())