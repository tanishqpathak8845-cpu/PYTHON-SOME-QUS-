# use a verable to represent a person's name and print a message to that person.

name = "tanishq"
message = "bro whattasup"
print(f"hey {name}", message)