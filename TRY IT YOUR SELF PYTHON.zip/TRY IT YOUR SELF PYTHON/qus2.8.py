# remove suffix method 
link = "https://google.com"
link1 = "https://google.com"
link1.removeprefix('https://')
print(link1)